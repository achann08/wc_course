// Can also be used with $(document).ready()
jQuery(window).load(function() {
    jQuery('.flexslider').flexslider({
        animation: "slide"
    });
});