import "../css/style.scss";

import scriptNavbar from "./modules/script-navbar";

const navbar = new scriptNavbar();